module.exports = {
    
    // database: 'mongodb://domin:pass@domin.ir:27017/domin?authSource=dumin'
    database: 'mongodb://localhost:27017/unitest'
}